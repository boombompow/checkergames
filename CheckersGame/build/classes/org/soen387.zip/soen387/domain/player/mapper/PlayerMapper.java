package org.soen387.domain.player.mapper;

public class PlayerMapper {

}
